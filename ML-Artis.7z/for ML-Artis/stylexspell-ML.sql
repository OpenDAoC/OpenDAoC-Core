INSERT INTO `stylexspell` (`StyleXSpell_ID`, `SpellID`, `ClassID`, `StyleID`, `Chance`, `LastTimeRowUpdated`) VALUES ('battlemaster_ML1_19', 32020, 19, 403, 100, '2000-01-01 00:00:00');
INSERT INTO `stylexspell` (`StyleXSpell_ID`, `SpellID`, `ClassID`, `StyleID`, `Chance`, `LastTimeRowUpdated`) VALUES ('battlemaster_ML1', 32020, 0, 403, 100, '2000-01-01 00:00:00');
INSERT INTO `stylexspell` (`StyleXSpell_ID`, `SpellID`, `ClassID`, `StyleID`, `Chance`, `LastTimeRowUpdated`) VALUES ('battlemaster_ML3', 32021, 0, 404, 100, '2000-01-01 00:00:00');
INSERT INTO `stylexspell` (`StyleXSpell_ID`, `SpellID`, `ClassID`, `StyleID`, `Chance`, `LastTimeRowUpdated`) VALUES ('battlemaster_ML5', 32022, 0, 401, 100, '2000-01-01 00:00:00');
INSERT INTO `stylexspell` (`StyleXSpell_ID`, `SpellID`, `ClassID`, `StyleID`, `Chance`, `LastTimeRowUpdated`) VALUES ('battlemaster_ML7', 32023, 0, 405, 100, '2000-01-01 00:00:00');
INSERT INTO `stylexspell` (`StyleXSpell_ID`, `SpellID`, `ClassID`, `StyleID`, `Chance`, `LastTimeRowUpdated`) VALUES ('battlemaster_ML9', 32024, 0, 406, 100, '2000-01-01 00:00:00');
INSERT INTO `stylexspell` (`StyleXSpell_ID`, `SpellID`, `ClassID`, `StyleID`, `Chance`, `LastTimeRowUpdated`) VALUES ('battlemaster_ML10', 32025, 0, 407, 100, '2000-01-01 00:00:00');
